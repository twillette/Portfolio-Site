package asteroids;
import java.awt.Color;
import java.awt.Graphics;
/**
 * Author: Thomas Willette
 * Date: March 3rd, 2017
 * File: Enemy.java
 */
public class Enemy extends DrawableObject{
    public Enemy(int x, int y, Color c) {
        super(x,y,30,30,c);
    }
    public void update(Player a) {
        if (getY() + getH() >= a.getY() && getY() <= a.getY() + a.getH() && getX() + getW() >= a.getX() && getX() <= a.getX() + a.getW()) {
            try {
                Thread.sleep(2000);
            } catch (Exception e) {}
            System.exit(0);
        }
        if (getY() >= 500) {
            super.update(0, -550);
        } else {
            super.update(0, 7);
        }
    }
}
