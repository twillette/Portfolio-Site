package asteroids;
import java.awt.Color;
import java.awt.Graphics;
import java.util.*;
/**
 * Author: Thomas Willette
 * Date: March 3rd, 2017
 * File: Projectile.java
 */
public class Projectile extends DrawableObject{
    public Projectile(int x, int y, Color c) {
        super(x,y,20,20,c);
    }
    public void update(ArrayList<Enemy> a) {
        if (!a.isEmpty()) {
            for (int i = 0; i < a.size(); i++) {
                if (((getX() >= a.get(i).getX() && getX() <= a.get(i).getX() + a.get(i).getW()) || (getX() + getW() >= a.get(i).getX() && getX() + getW() <= a.get(i).getX() + a.get(i).getW())) && getY() <= a.get(i).getY() + a.get(i).getH()) {
                    a.remove(i);
                    
                }
            }
        }
        super.update(0, -25);
    }
}
