package asteroids;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
/**
 * Author: Thomas Willette
 * Date: March 3rd, 2017
 * File: Asteroids.java
 */

/* HOW TO PLAY:
Asteroids are falling from the top of the screen. Move left or right to dodge them. Press space to shoot the asteroids. 
Once you shoot them all, you win! If one of them hits you, you die!
*/
public class Asteroids extends Applet implements KeyListener{
    Random rand = new Random();
    ArrayList<Enemy> enemies = new ArrayList<>();
    Player p = new Player(475,450, 50, 50, Color.RED);
    
    @Override
    public void init() {
        addKeyListener(this);
        requestFocus();
        for (int i = 20; i > 0; i--)  {
            enemies.add(new Enemy(rand.nextInt(950), rand.nextInt(300), Color.WHITE));
        }
    }
    @Override
    public void paint(Graphics g) {
        setSize(1000,500);
        setBackground(Color.BLACK);
        showStatus("Asteroids! Shoot them all to win! | Controls: | ->: Right | <-: Left | Space: Shoots ");
        p.draw(g, enemies);
        if (!enemies.isEmpty()) {
            for (int i = 0; i < enemies.size(); i++) {
                enemies.get(i).draw(g);
                enemies.get(i).update(p);
            }  
        } else{
            try {
                showStatus("Winner!");
                Thread.sleep(2000);
            } catch (Exception e) {}
            System.exit(0);
        }
        
        try {
            Thread.sleep(30);
            repaint();
        } catch (Exception e) {}
    }
    @Override
    public void keyTyped(KeyEvent ke) {
        //throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void keyPressed(KeyEvent k) {
        int key = k.getKeyCode();
        p.update(key);
        //repaint();
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        //throw new UnsupportedOperationException("Not supported yet."); 
    }

    
    
}
