package asteroids;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.*;
/*
 * Author: Thomas Willette
 * Date: March 3rd, 2017
 * File: Player.java
 */
public class Player extends DrawableObject {
    private ArrayList<Projectile> proj = new ArrayList<>();
    public Player(int x, int y, int w, int h, Color c) {
        super(x,y,w,h,c);
    }
    
    public void update(int key) {
        if (key == KeyEvent.VK_LEFT) {
            super.update(-25, 0);
        } else if (key == KeyEvent.VK_RIGHT) {
            super.update(25,0);
        } else if (key == KeyEvent.VK_SPACE) {
            proj.add(new Projectile(getX() + 15, getY() - 20, Color.BLUE));
        }
    }

    public void draw(Graphics g, ArrayList<Enemy> a) {
        super.draw(g);
        if (!proj.isEmpty()) {
            for(int i = 0; i < proj.size(); i++) {
                proj.get(i).draw(g);
                proj.get(i).update(a);
                if (proj.get(i).getY() == -20) {
                    proj.remove(i);
                }
                
            }
        }
    }
}
