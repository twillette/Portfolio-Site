package asteroids;
import java.awt.Color;
import java.awt.Graphics;
/*
 * Author: Thomas Willette
 * Date: March 3rd, 2017
 * File: DrawableObject.java
 */
public class DrawableObject {
    private int x;
    private int y;
    private int w;
    private int h;
    private Color c;
    
    public DrawableObject(int x1, int y1, int w1, int h1, Color c1) {
        x = x1;
        y = y1;
        w = w1;
        h = h1;
        c = c1;
    }
    
    public void draw(Graphics g) {
        g.setColor(c);
        g.fillRect(x, y, w, h);
    }
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    public int getW() {
        return w;
    }
    public int getH() {
        return h;
    }
    public void update(int xvel, int yvel) {
        if (x > -1 && xvel < 0) {
            x = x + xvel;
        } else if (x < 951 && xvel > 0) {
            x = x + xvel;
        }
        y = y + yvel;
    }
}
