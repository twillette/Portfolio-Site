#Authors: Thomas Willette & Nick Fletcher | Date: May 16th, - May 17th, 2016
Shoes.app(title:"Tic-Tac-Toe", width: 700, height: 700, resizeable: false) do
    background ("Board.png") 
    Shoes.APPS.each {|a| a.set_window_icon_path("blank circle.png") }
    turn = 1
    pos1 = "n"
    pos2 = "n"
    pos3 = "n"
    pos4 = "n"
    pos5 = "n"
    pos6 = "n"
    pos7 = "n"
    pos8 = "n"
    pos9 = "n"
    pos1c = "n"
    pos2c = "n"
    pos3c = "n"
    pos4c = "n"
    pos5c = "n"
    pos6c = "n"
    pos7c = "n"
    pos8c = "n"
    pos9c = "n"
    alert "Welcome to Tic-Tac-Toe. Use the number keys to place your marker."
    keypress do |k|
    	var = k
      if turn % 2 != 0
      	if var == "1" && pos1 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 1,1,229
      		pos1 = "y"
          pos1c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "2" && pos2 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 234,1,229
      		pos2 = "y"
          pos2c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "3" && pos3 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 468,1,229
      		pos3 = "y"
          pos3c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "4" && pos4 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 1,235,229
      		pos4 = "y"
          pos4c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "5" && pos5 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 235,235,229
      		pos5 = "y"
          pos5c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "6" && pos6 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 469,235,229
      		pos6 = "y"
          pos6c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "7" && pos7 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 1,469,229
      		pos7 = "y"
          pos7c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "8" && pos8 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 234,469,229
      		pos8 = "y"
          pos8c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	elsif var == "9" && pos9 != "y"
      		stroke black
     			strokewidth 4
     			fill blue
      		oval 469,469,229
      		pos9 = "y"
          pos9c = "b"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
      	end
      else
        if var == "1" && pos1 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 1,1,229
          pos1 = "y"
          pos1c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "2" && pos2 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 234,1,229
          pos2 = "y"
          pos2c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "3" && pos3 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 468,1,229
          pos3 = "y"
          pos3c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "4" && pos4 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 1,235,229
          pos4 = "y"
          pos4c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "5" && pos5 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 235,235,229
          pos5 = "y"
          pos5c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "6" && pos6 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 469,235,229
          pos6 = "y"
          pos6c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "7" && pos7 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 1,469,229
          pos7 = "y"
          pos7c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "8" && pos8 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 234,469,229
          pos8 = "y"
          pos8c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        elsif var == "9" && pos9 != "y"
          stroke black
          strokewidth 4
          fill red
          oval 469,469,229
          pos9 = "y"
          pos9c = "r"
          turn = turn + 1
          if pos1c == "r" && pos2c == "r" && pos3c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos4c == "r" && pos5c == "r" && pos6c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos7c == "r" && pos8c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos4c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos2c == "r" && pos5c == "r" && pos8c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos6c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos1c == "r" && pos5c == "r" && pos9c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!
          elsif pos3c == "r" && pos5c == "r" && pos7c == "r"
            alert "CONGRATS RED YOU WON!"
            exit!

          elsif pos1c == "b" && pos2c == "b" && pos3c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos4c == "b" && pos5c == "b" && pos6c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos7c == "b" && pos8c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos4c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos2c == "b" && pos5c == "b" && pos8c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos6c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos1c == "b" && pos5c == "b" && pos9c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          elsif pos3c == "b" && pos5c == "b" && pos7c == "b"
            alert "CONGRATS BLUE YOU WON!"
            exit!
          end
        end
      end
    end
end