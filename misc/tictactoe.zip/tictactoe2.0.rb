#Authors: Thomas Willette & Nick Fletcher | Date: May 16th, - May 20th, 2016
#Above & Beyond Version
Shoes.app(title:"Tic-Tac-Toe", width: 700, height: 700, resizeable: false) do
    Shoes.APPS.each {|a| a.set_window_icon_path("blank circle.png") }
    turn = 1
    background ("Board.png")
    default = ["n","n","n","n","n","n","n","n","n","n"]
    def check(pos1, pos2, pos3, default)
        if pos1 == "r" && pos2 == "r" && pos3 == "r"
          alert "CONGRATS RED YOU WON!"
          default = ["n","n","n","n","n","n","n","n","n","n"]
          @pos = default
          @posc = default
          turn = 1
          background ("Blank Board.png")
          @ans = ask("Would you like to play again? [y/n]")
            if @ans == "y" || @ans == "Y"
                background ("Board.png")
            else
                exit!
            end 
        elsif pos1 == "b" && pos2 == "b" && pos3 == "b"
          alert "CONGRATS BLUE YOU WON!"
          default = ["n","n","n","n","n","n","n","n","n","n"]
          @pos = default
          @posc = default
          turn = 1
          background ("Blank Board.png")
          @ans = ask("Would you like to play again? [y/n]")
            if @ans == "y" || @ans == "Y"
                background ("Board.png")
            else
                exit!
            end 
        end
      end 
    def checktie(pos1, pos2, pos3, pos4, pos5, pos6, pos7, pos8, pos9, default)
        if pos1 == "z" && pos2 == "z" && pos3 == "z" && pos4 == "z" && pos5 == "z" && pos6 == "z" && pos7 == "z" && pos8 == "z" && pos9 == "z"
            alert "No one wins. Draw."
            default = ["n","n","n","n","n","n","n","n","n","n"]
            @pos = default
            @posc = default
            turn = 1
            background ("Blank Board.png")
            @ans = ask("Would you like to play again? [y/n]")
                if @ans == "y" || @ans == "Y"
                    background ("Board.png")
                else
                    exit!
                end 
            end
        end
      turn = 1
      @pos = ["n","n","n","n","n","n","n","n","n"]
      @posc = ["n","n","n","n","n","n","n","n","n"]
      alert "Welcome to Tic-Tac-Toe. Use the number keys to choose your position."
      keypress do |k|
      var = k
        if turn % 2 != 0
        	if var == "1" && @pos[1] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 1,1,229
        		@pos[1] = "z"
                @posc[1] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "2" && @pos[2] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 234,1,229
        		@pos[2] = "z"
                @posc[2] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "3" && @pos[3] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 468,1,229
        		@pos[3] = "z"
                @posc[3] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "4" && @pos[4] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 1,235,229
        		@pos[4] = "z"
                @posc[4] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "5" && @pos[5] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 235,235,229
        		@pos[5] = "z"
                @posc[5] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "6" && @pos[6] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 469,235,229
        		@pos[6] = "z"
                @posc[6] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "7" && @pos[7] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 1,469,229
        		@pos[7] = "z"
                @posc[7] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "8" && @pos[8] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 234,469,229
        		@pos[8] = "z"
                @posc[8] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	elsif var == "9" && @pos[9] != "z"
        		stroke black
       			strokewidth 4
       			fill blue
        		oval 469,469,229
        		@pos[9] = "z"
                @posc[9] = "b"
                turn = turn + 1
                checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
                check(@posc[1], @posc[2], @posc[3],default)
                check(@posc[4], @posc[5], @posc[6],default)
                check(@posc[7], @posc[8], @posc[9],default)
                check(@posc[1], @posc[4], @posc[7],default)
                check(@posc[2], @posc[5], @posc[8],default)
                check(@posc[3], @posc[6], @posc[9],default)
                check(@posc[1], @posc[5], @posc[9],default)
                check(@posc[3], @posc[5], @posc[7],default)
        	end
        else
          if var == "1" && @pos[1] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 1,1,229
            @pos[1] = "z"
            @posc[1] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "2" && @pos[2] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 234,1,229
            @pos[2] = "z"
            @posc[2] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "3" && @pos[3] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 468,1,229
            @pos[3] = "z"
            @posc[3] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "4" && @pos[4] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 1,235,229
            @pos[4] = "z"
            @posc[4] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "5" && @pos[5] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 235,235,229
            @pos[5] = "z"
            @posc[5] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "6" && @pos[6] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 469,235,229
            @pos[6] = "z"
            @posc[6] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "7" && @pos[7] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 1,469,229
            @pos[7] = "z"
            @posc[7] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "8" && @pos[8] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 234,469,229
            @pos[8] = "z"
            @posc[8] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          elsif var == "9" && @pos[9] != "z"
            stroke black
            strokewidth 4
            fill red
            oval 469,469,229
            @pos[9] = "z"
            @posc[9] = "r"
            turn = turn + 1
            checktie(@pos[1], @pos[2], @pos[3], @pos[4], @pos[5], @pos[6], @pos[7], @pos[8], @pos[9], default)
            check(@posc[1], @posc[2], @posc[3],default)
            check(@posc[4], @posc[5], @posc[6],default)
            check(@posc[7], @posc[8], @posc[9],default)
            check(@posc[1], @posc[4], @posc[7],default)
            check(@posc[2], @posc[5], @posc[8],default)
            check(@posc[3], @posc[6], @posc[9],default)
            check(@posc[1], @posc[5], @posc[9],default)
            check(@posc[3], @posc[5], @posc[7],default)
          end
        end
      end
end